(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-0658afd4-9da5-4d1b-91e5-500124fd310a .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-0055e66a-e318-4970-b2e3-d183a4b35d2b .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-9e5672d2-a48c-4fe8-915d-d9da4315604f .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-47367f2c-8399-43c5-8441-d42e12f32bb4 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-bcb47656-eeca-4e05-97a1-2bdd96f81077 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-b5da74c7-7e43-465d-8df2-10709390a006 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-8457a0d4-849a-4b56-b4df-2e20082fcc82 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-c950fb47-f42f-463c-aa49-3cef92dcb680 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-4625ba50-b2ff-4502-bbed-a70911c4ddbf .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-a87a9967-f868-4fd4-8675-3b002ee02a2c .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-6a2ce647-5beb-4d1e-a34c-c92ce2f57ca5 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-674bda2e-7b1a-427b-abcb-dfb807518a06 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-e3fb2985-82f8-4494-a0e3-caa729bd3b4a .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-17201529-471b-4e5e-83d4-aabebf823692 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-761074ab-4e8b-4c76-ba73-2602f46ece70 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-ecc00968-35fb-49c3-98f1-df2c42cfe25a .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-351cbaa4-ec4f-4457-b778-646c79c17d8c .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-e22fa880-1671-47b5-ab86-568c50ba2f18 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-72c2b95e-b14f-4f8d-a1fb-aad5201ee2d6 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-c4dcf3fe-8a6e-431d-a31d-23e387f59423 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);